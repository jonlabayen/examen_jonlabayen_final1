<?php

return [


    /*
    |--------------------------------------------------------------------------
    | App Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used in the main app.
    |
    */
    'main_title' => 'Escribe tu nombre',
    'main_text'  => 'Has conseguido poner en marcha la aplicación web!! <br>Anota aquí mismo cómo has resuelto el ejercicio 2 del examen.',
    'exam' => 'EXAMEN',
    'cycle_students' => 'Alumnos de un ciclo',
    'student_to_cycle' => 'Asignar alumnos/cicle',
    'student_to_company' => 'Asignar alumno/a a empresa',
    'new_student' => 'Nuevo alumno',


];
