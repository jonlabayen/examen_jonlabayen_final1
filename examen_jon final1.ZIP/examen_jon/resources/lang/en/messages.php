<?php

return [


    /*
    |--------------------------------------------------------------------------
    | App Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used in the main app.
    |
    */
    'main_title' => 'Write your name',
    'main_text'  => 'Congratulations, you have started the application! <br>Write down right here how you solved the second exercise.',
    'exam' => 'EXAM',
    'cycle_students' => 'Students of cycle',
    'student_to_cycle' => 'Assign student to cycle',
    'student_to_company' => 'Assign student to company',
    'new_student' => 'New student',

];
