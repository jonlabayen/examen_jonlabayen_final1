@extends('layouts.app')

@section('title', 'UD5. ORM')

@section('content')

  <h4>Nuevo/a alumno/a</h4>
  <form action="" method="post">

  </form>
  <br>

@endsection
