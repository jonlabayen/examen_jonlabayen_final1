@extends('layouts.app')

@section('title', 'UD5. ORM')

@section('content')

  <h2>Alumnos de un ciclo</h2>

  <table>
    <tr>

    </tr>


  </table>

@endsection
