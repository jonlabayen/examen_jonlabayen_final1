@extends('layouts.app')

@section('title', 'UD5. ORM')

@section('content')

  <h2>Asignar alumno al ciclo</h2>

  <table>
    <tr>

    </tr>

  </table>

@endsection
