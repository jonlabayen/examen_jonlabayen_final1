@extends('layouts.app')

@section('title', 'UD5. ORM')

@section('content')

  <h2>Asignar alumno/a a empresa</h2>

  <form>


  </form>

  <h3>Listado de alumnos y las empresas a las que están asignados:</h3>

  <table>
    <tr>
      <th>Hotel</th>
      <th>Fecha</th>
      <th>Numero de habitaciones</th>
    </tr>


  </table>
@endsection
