@extends('layouts.app')

@section('title', 'EXAM')

@section('content')

  <h3>@lang('messages.main_title')</h3>
  @lang('messages.main_text')
@endsection
